package Cem.Dias.RoadmapJava.javacore.Aintroducaoclasses.dominio;
//introdução a orientação objetos
//cria-se uma classe onde se faz um "molde" do objeto em questão, exemplo, student:
public class Student {
    public String name;
    public int age;
    public char gender;
}
